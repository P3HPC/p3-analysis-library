#!/usr/bin/env python3
# Copyright (c) 2023 Intel Corporation
# SPDX-License-Identifier: 0BSD
"""
Simple Cascade
==============

A simple cascade plot.

This example uses the synthetic performance efficiency data introduced
in the paper "`Interpreting and Visualizing Performance Portability Metrics`_"
to demonstrate the structure and interpretation of a cascade plot.

The dataset contains application efficiency for six hypothetical applications:

1. **Unportable**: Runs on only one platform.
2. **Single Target**: Runs everywhere, but with high efficiency on one platform.
3. **Multi-Target**: Runs everywhere, with high efficiency on half of the platforms.
4. **Consistent (30%)**: Runs everywhere, with 30% efficiency.
5. **Consistent (70%)**: Runs everywhere, with 70% efficiency.
6. **Inconsistent**: Runs everywhere, with inconsistent efficiency.

The line chart shows the efficiency of each application for every platform it
supports. Platforms are sorted individually for each application, in decreasing
order of application efficiency.

The boxes underneath the line chart show which platform is associated with each
point in the line chart, for each application.

The bar chart shows the performance portability of each application.

.. _Interpreting and Visualizing Performance Portability Metrics: https://doi.org/10.1109/P3HPC51967.2020.00007
"""

# Initialize synthetic performance efficiency data
# (not shown, but available in script download)
from collections import defaultdict

import pandas as pd

import p3analysis

data = defaultdict(list)
for i in range(0, 50):
    data["problem"] += ["problem"]
    data["platform"] += ["platform " + str(i)]
    data["application"] += ["application"]
    data["app eff"] += [0.5]
    data["fom"] += [1.0]

# Read performance efficiency data into pandas DataFrame
df = pd.DataFrame(data)

# Generate a cascade plot
cascade = p3analysis.plot.cascade(df)
cascade.save("big_cascade.png")
